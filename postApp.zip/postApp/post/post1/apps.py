from django.apps import AppConfig


class Post1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'post1'
